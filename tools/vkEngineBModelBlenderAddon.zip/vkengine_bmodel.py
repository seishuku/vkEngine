bl_info = {
    "name": "vkEngine BModel",
    "author": "vkEngine",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "File > Import/Export > vkEngine BModel",
    "description": "Import and export the vkEngine BModel and BAnim formats.",
    "category": "Import-Export",
}

import bpy
import bmesh
import os
import struct
from mathutils import Matrix, Quaternion, Vector


# BModel/vkEngine uses a right-handed Y-up coordinate system. Blender uses
# right-handed Z-up coordinates. This is a +90 degree rotation around X:
#   Blender (x, y, z) -> vkEngine (x, z, -y)
BLENDER_TO_BMODEL = Matrix((
    (1.0, 0.0, 0.0, 0.0),
    (0.0, 0.0, 1.0, 0.0),
    (0.0, -1.0, 0.0, 0.0),
    (0.0, 0.0, 0.0, 1.0),
))
BMODEL_TO_BLENDER = BLENDER_TO_BMODEL.inverted()


def transform_bmodel_position(value):
    return BLENDER_TO_BMODEL @ Vector(value)


def transform_bmodel_direction(value):
    return BLENDER_TO_BMODEL.to_3x3() @ Vector(value)


def transform_bmodel_matrix(matrix):
    return BLENDER_TO_BMODEL @ matrix @ BMODEL_TO_BLENDER


# ---------------------------------------------------------------------------
# BModel binary format
#
# All integer/float values are little-endian.
#
# Header:
#   uint32 BMDL
#   uint32 material count
#   materials...
#   uint32 mesh count
#   meshes...
#   uint32 vertex count
#   chunks until EOF:
#       VERT: float[3] * vertex_count
#       TEXC: float[2] * vertex_count
#       TANG: float[3] * vertex_count
#       BNRM: float[3] * vertex_count
#       NORM: float[3] * vertex_count
#       BONE: uint32 bone_count, then bone records:
#             NUL string name, int32 parent, float[3] position, float[4] orientation
#       BWGT: uint32 bone[4] + float weight[4] per vertex
#
# Strings are NUL-terminated UTF-8 strings (not fixed 256-byte records).
# ---------------------------------------------------------------------------

MAGIC_BMDL = struct.unpack("<I", b"BMDL")[0]
MAGIC_MESH = struct.unpack("<I", b"MESH")[0]
MAGIC_MATL = struct.unpack("<I", b"MATL")[0]
MAGIC_VERT = struct.unpack("<I", b"VERT")[0]
MAGIC_TEXC = struct.unpack("<I", b"TEXC")[0]
MAGIC_TANG = struct.unpack("<I", b"TANG")[0]
MAGIC_BNRM = struct.unpack("<I", b"BNRM")[0]
MAGIC_NORM = struct.unpack("<I", b"NORM")[0]
MAGIC_BONE = struct.unpack("<I", b"BONE")[0]
MAGIC_BWGT = struct.unpack("<I", b"BWGT")[0]


def read_u32(f):
    data = f.read(4)
    if len(data) != 4:
        raise ValueError("Unexpected end of BModel file.")
    return struct.unpack("<I", data)[0]


def read_f32(f, count):
    data = f.read(4 * count)
    if len(data) != 4 * count:
        raise ValueError("Unexpected end of BModel file.")
    return struct.unpack("<" + "f" * count, data)


def read_cstring(f, max_len=1024 * 1024):
    data = bytearray()
    while len(data) < max_len:
        ch = f.read(1)
        if not ch:
            raise ValueError("Unexpected end of BModel file while reading string.")
        if ch == b"\0":
            return data.decode("utf-8", errors="replace")
        data.extend(ch)
    raise ValueError("BModel string is too long.")


def write_u32(f, value):
    f.write(struct.pack("<I", int(value)))


def write_f32(f, values):
    f.write(struct.pack("<" + "f" * len(values), *values))


def write_cstring(f, value):
    if value is None:
        value = ""
    value = str(value)
    raw = value.encode("utf-8", errors="replace")
    if b"\0" in raw:
        raw = raw.split(b"\0", 1)[0]
    f.write(raw)
    f.write(b"\0")


def safe_name(name, fallback):
    name = (name or "").strip()
    return name if name else fallback


# ---------------------------------------------------------------------------
# Material conversion
# ---------------------------------------------------------------------------

def _node_input(node, names):
    for name in names:
        socket = node.inputs.get(name)
        if socket is not None:
            return socket
    return None


def _socket_color(socket, default):
    if socket is None:
        return default
    try:
        value = socket.default_value
        if len(value) >= 3:
            return (float(value[0]), float(value[1]), float(value[2]))
    except Exception:
        pass
    return default


def _socket_float(socket, default):
    if socket is None:
        return default
    try:
        return float(socket.default_value)
    except Exception:
        return default


def material_to_bmodel(mat, output_dir):
    """Convert a Blender material into the BModel material representation."""
    if mat is None:
        return {
            "name": "DefaultMaterial",
            "ambient": (0.1, 0.1, 0.1),
            "diffuse": (0.8, 0.8, 0.8),
            "specular": (0.5, 0.5, 0.5),
            "emission": (0.0, 0.0, 0.0),
            "shininess": 32.0,
            "texture": "",
        }

    ambient = (0.1, 0.1, 0.1)
    diffuse = (0.8, 0.8, 0.8)
    specular = (0.5, 0.5, 0.5)
    emission = (0.0, 0.0, 0.0)
    roughness = 0.5

    if mat.use_nodes and mat.node_tree:
        principled = None
        for node in mat.node_tree.nodes:
            if node.type == "BSDF_PRINCIPLED":
                principled = node
                break

        if principled:
            diffuse = _socket_color(
                _node_input(principled, ("Base Color",)), diffuse
            )

            # Blender 4.x calls this "Specular IOR Level"; older Blender
            # versions generally expose "Specular".
            specular = (
                _socket_float(
                    _node_input(principled, ("Specular IOR Level", "Specular")),
                    0.5,
                ),
            ) * 3

            emission = _socket_color(
                _node_input(principled, ("Emission Color", "Emission")),
                emission,
            )
            roughness = _socket_float(
                _node_input(principled, ("Roughness",)),
                roughness,
            )

    # BModel's shininess is a Phong-style exponent.  Convert Blender
    # roughness into a useful equivalent range.
    shininess = max(1.0, min(1024.0, ((1.0 - max(0.0, min(1.0, roughness))) ** 4) * 1024.0))

    texture = ""
    if mat.use_nodes and mat.node_tree:
        principled = next(
            (n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"),
            None,
        )
        if principled:
            base = _node_input(principled, ("Base Color",))
            if base and base.links:
                for link in base.links:
                    node = link.from_node
                    if node.type == "TEX_IMAGE" and node.image:
                        image_path = bpy.path.abspath(node.image.filepath)
                        if image_path:
                            try:
                                texture = os.path.relpath(
                                    image_path, output_dir
                                ).replace("\\", "/")
                            except ValueError:
                                texture = image_path.replace("\\", "/")
                        break

    return {
        "name": safe_name(mat.name, "DefaultMaterial"),
        "ambient": ambient,
        "diffuse": diffuse,
        "specular": specular,
        "emission": emission,
        "shininess": shininess,
        "texture": texture,
    }


def make_blender_material(data, base_dir):
    name = safe_name(data["name"], "DefaultMaterial")
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)

    mat.use_nodes = True
    nt = mat.node_tree
    principled = next(
        (n for n in nt.nodes if n.type == "BSDF_PRINCIPLED"), None
    )
    if principled is None:
        principled = nt.nodes.new("ShaderNodeBsdfPrincipled")

    def set_color(names, value):
        socket = _node_input(principled, names)
        if socket:
            socket.default_value = (
                float(value[0]), float(value[1]), float(value[2]), 1.0
            )

    set_color(("Base Color",), data["diffuse"])
    set_color(("Emission Color", "Emission"), data["emission"])

    # Convert the BModel Phong exponent back into a roughness approximation.
    shininess = max(1.0, float(data["shininess"]))
    roughness = max(0.0, min(1.0, 1.0 - (shininess / 1024.0) ** 0.25))
    socket = _node_input(principled, ("Roughness",))
    if socket:
        socket.default_value = roughness

    texture_name = data.get("texture", "")
    if texture_name:
        image_path = texture_name
        if not os.path.isabs(image_path):
            image_path = os.path.normpath(os.path.join(base_dir, image_path))

        try:
            image = bpy.data.images.load(image_path, check_existing=True)
            tex = None
            for node in nt.nodes:
                if node.type == "TEX_IMAGE" and node.image == image:
                    tex = node
                    break
            if tex is None:
                tex = nt.nodes.new("ShaderNodeTexImage")
                tex.image = image

            base = _node_input(principled, ("Base Color",))
            if base and not base.links:
                nt.links.new(tex.outputs["Color"], base)
        except Exception:
            # The BModel stores a path, not image data.  Preserve the material
            # even if the image is not available beside the model.
            pass

    return mat


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

def read_bmodel(filepath):
    with open(filepath, "rb") as f:
        if read_u32(f) != MAGIC_BMDL:
            raise ValueError("Not a BModel file.")

        materials = []
        material_count = read_u32(f)

        for _ in range(material_count):
            if read_u32(f) != MAGIC_MATL:
                raise ValueError("Invalid BModel material chunk.")

            materials.append({
                "name": read_cstring(f),
                "ambient": read_f32(f, 3),
                "diffuse": read_f32(f, 3),
                "specular": read_f32(f, 3),
                "emission": read_f32(f, 3),
                "shininess": read_f32(f, 1)[0],
                "texture": read_cstring(f),
            })

        meshes = []
        mesh_count = read_u32(f)

        for _ in range(mesh_count):
            if read_u32(f) != MAGIC_MESH:
                raise ValueError("Invalid BModel mesh chunk.")

            name = read_cstring(f)
            material_name = read_cstring(f)
            face_count = read_u32(f)

            indices = []
            if face_count:
                data = f.read(face_count * 3 * 4)
                if len(data) != face_count * 3 * 4:
                    raise ValueError("Unexpected end of BModel index data.")
                indices = list(struct.unpack("<" + "I" * (face_count * 3), data))

            meshes.append({
                "name": name,
                "material_name": material_name,
                "indices": indices,
            })

        vertex_count = read_u32(f)
        chunks = {}

        while True:
            raw = f.read(4)
            if not raw:
                break
            if len(raw) != 4:
                raise ValueError("Truncated BModel chunk.")

            magic = struct.unpack("<I", raw)[0]

            if magic == MAGIC_VERT:
                chunks["vertex"] = read_f32(f, vertex_count * 3)
            elif magic == MAGIC_TEXC:
                chunks["uv"] = read_f32(f, vertex_count * 2)
            elif magic == MAGIC_TANG:
                chunks["tangent"] = read_f32(f, vertex_count * 3)
            elif magic == MAGIC_BNRM:
                chunks["binormal"] = read_f32(f, vertex_count * 3)
            elif magic == MAGIC_NORM:
                chunks["normal"] = read_f32(f, vertex_count * 3)
            elif magic == MAGIC_BONE:
                bone_count = read_u32(f)
                bones = []
                for _ in range(bone_count):
                    bones.append({
                        "name": read_cstring(f),
                        "parent": struct.unpack("<i", f.read(4))[0],
                        "position": read_f32(f, 3),
                        "orientation": read_f32(f, 4),
                    })
                chunks["bones"] = bones
            elif magic == MAGIC_BWGT:
                weights = []
                for _ in range(vertex_count):
                    bone = struct.unpack("<IIII", f.read(16))
                    weight = read_f32(f, 4)
                    weights.append({"bone": bone, "weight": weight})
                chunks["weights"] = weights
            else:
                # The engine loader ignores unknown chunks, but it has no
                # length field, so there is no safe way to skip one here.
                raise ValueError(
                    "Unknown BModel chunk 0x%08X; cannot safely continue." % magic
                )

        if "vertex" not in chunks:
            raise ValueError("BModel has no vertex data.")

        return materials, meshes, vertex_count, chunks


def import_bmodel(filepath):
    materials, meshes, vertex_count, data = read_bmodel(filepath)
    base_dir = os.path.dirname(os.path.abspath(filepath))

    if not materials:
        materials = [{
            "name": "DefaultMaterial",
            "ambient": (0.1, 0.1, 0.1),
            "diffuse": (0.8, 0.8, 0.8),
            "specular": (0.5, 0.5, 0.5),
            "emission": (0.0, 0.0, 0.0),
            "shininess": 32.0,
            "texture": "",
        }]

    blender_materials = [
        make_blender_material(m, base_dir) for m in materials
    ]
    material_map = {m["name"]: i for i, m in enumerate(materials)}

    # Create one Blender object per BModel mesh.  BModel indices are global,
    # so each object receives only the vertices referenced by that mesh.
    created = []

    positions = data["vertex"]
    uvs = data.get("uv")
    normals = data.get("normal")
    tangents = data.get("tangent")
    binormals = data.get("binormal")
    bones = data.get("bones", [])
    weights = data.get("weights")

    for bmesh_data in meshes:
        global_indices = bmesh_data["indices"]
        if not global_indices:
            continue

        local_map = {}
        local_vertices = []
        local_indices = []

        # Preserve one-to-one vertex attributes.  Since a BModel vertex owns
        # all attributes, no extra split is necessary during import.
        for gi in global_indices:
            if gi >= vertex_count:
                raise ValueError("BModel index is outside the vertex array.")

            li = local_map.get(gi)
            if li is None:
                li = len(local_vertices)
                local_map[gi] = li
                local_vertices.append(gi)
            local_indices.append(li)

        verts = []
        for i in local_vertices:
            p = BMODEL_TO_BLENDER @ Vector((
                positions[3*i], positions[3*i+1], positions[3*i+2]
            ))
            verts.append((p.x, p.y, p.z))
        faces = [
            tuple(local_indices[i:i+3])
            for i in range(0, len(local_indices), 3)
        ]

        mesh = bpy.data.meshes.new(safe_name(bmesh_data["name"], "BModelMesh"))
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        obj = bpy.data.objects.new(
            safe_name(bmesh_data["name"], "BModelMesh"), mesh
        )
        bpy.context.collection.objects.link(obj)

        for mat in blender_materials:
            mesh.materials.append(mat)

        mat_index = material_map.get(bmesh_data["material_name"], 0)
        for poly in mesh.polygons:
            poly.material_index = mat_index

        # UVs are loop-domain data in Blender, while BModel stores one UV per
        # vertex.  Because exported BModel vertices are split where needed,
        # this maps exactly.
        if uvs is not None:
            uv_layer = mesh.uv_layers.new(name="UVMap")
            for poly in mesh.polygons:
                for loop_index in poly.loop_indices:
                    vi = mesh.loops[loop_index].vertex_index
                    gi = local_vertices[vi]
                    uv_layer.data[loop_index].uv = (
                        uvs[2*gi],
                        1.0 - uvs[2*gi+1],
                    )

        # Preserve source tangent-space vectors as custom point attributes.
        # Blender calculates its own runtime tangents, so custom attributes
        # are used when exact BModel data needs to survive a round trip.
        if normals is not None:
            attr = mesh.attributes.new(
                "BMODEL_NORMAL", "FLOAT_VECTOR", "POINT"
            )
            for vi, gi in enumerate(local_vertices):
                value = BMODEL_TO_BLENDER.to_3x3() @ Vector((
                    normals[3*gi], normals[3*gi+1], normals[3*gi+2]
                ))
                attr.data[vi].vector = value

        if tangents is not None:
            attr = mesh.attributes.new(
                "BMODEL_TANGENT", "FLOAT_VECTOR", "POINT"
            )
            for vi, gi in enumerate(local_vertices):
                value = BMODEL_TO_BLENDER.to_3x3() @ Vector((
                    tangents[3*gi], tangents[3*gi+1], tangents[3*gi+2]
                ))
                attr.data[vi].vector = value

        if binormals is not None:
            attr = mesh.attributes.new(
                "BMODEL_BINORMAL", "FLOAT_VECTOR", "POINT"
            )
            for vi, gi in enumerate(local_vertices):
                value = BMODEL_TO_BLENDER.to_3x3() @ Vector((
                    binormals[3*gi], binormals[3*gi+1], binormals[3*gi+2]
                ))
                attr.data[vi].vector = value

        if weights is not None:
            for slot, name in enumerate(("BMODEL_BONE0", "BMODEL_BONE1", "BMODEL_BONE2", "BMODEL_BONE3")):
                attr = mesh.attributes.new(name, "INT", "POINT")
                for vi, gi in enumerate(local_vertices):
                    attr.data[vi].value = int(weights[gi]["bone"][slot])

            for slot, name in enumerate(("BMODEL_WEIGHT0", "BMODEL_WEIGHT1", "BMODEL_WEIGHT2", "BMODEL_WEIGHT3")):
                attr = mesh.attributes.new(name, "FLOAT", "POINT")
                for vi, gi in enumerate(local_vertices):
                    attr.data[vi].value = float(weights[gi]["weight"][slot])

        obj["bmodel_material_name"] = bmesh_data["material_name"]
        obj["bmodel_source"] = os.path.basename(filepath)
        created.append(obj)

    if created and bones:
        arm_data = bpy.data.armatures.new(os.path.splitext(os.path.basename(filepath))[0])
        arm_obj = bpy.data.objects.new(arm_data.name, arm_data)
        bpy.context.collection.objects.link(arm_obj)
        bpy.context.view_layer.objects.active = arm_obj
        arm_obj.select_set(True)

        bpy.ops.object.mode_set(mode="EDIT")
        edit_bones = []

        # BModel stores bind-pose bone transforms relative to their PARENT
        # (root bones are relative to scene space). Reconstructing world/global
        # matrices therefore requires walking the parent chain - bone[i]'s
        # parent index is guaranteed to be less than i, so a single forward
        # pass suffices. BModel quaternions are stored as (x, y, z, w), while
        # Blender's Quaternion constructor expects (w, x, y, z).
        #
        # The armature object created below starts at an identity world
        # transform, so a root bone's stored transform (which already has the
        # exporting armature's world transform baked in) lands directly in the
        # new armature's local/armature space with no further adjustment.
        global_matrices = []
        for i, bone in enumerate(bones):
            position = Vector(bone["position"])
            qx, qy, qz, qw = bone["orientation"]
            orientation = Quaternion((qw, qx, qy, qz))
            local_matrix = (
                Matrix.Translation(position) @ orientation.to_matrix().to_4x4()
            )
            local_matrix = BMODEL_TO_BLENDER @ local_matrix @ BLENDER_TO_BMODEL

            parent_index = bone["parent"]
            if parent_index >= 0 and parent_index < i:
                global_matrices.append(global_matrices[parent_index] @ local_matrix)
            else:
                global_matrices.append(local_matrix)

        def get_global_matrix(index):
            return global_matrices[index]

        children = [[] for _ in bones]
        for i, bone in enumerate(bones):
            parent_index = bone["parent"]
            if parent_index >= 0 and parent_index < len(bones) and parent_index != i:
                children[parent_index].append(i)

        global_positions = [get_global_matrix(i).to_translation() for i in range(len(bones))]

        for i, bone in enumerate(bones):
            eb = arm_data.edit_bones.new(safe_name(bone["name"], "Bone"))
            head = global_positions[i]
            eb.head = head

            if children[i]:
                target = sum(
                    (global_positions[c] for c in children[i]),
                    Vector((0.0, 0.0, 0.0))
                )
                target /= len(children[i])
                direction = target - head
            else:
                parent_index = bone["parent"]
                if parent_index >= 0 and parent_index < len(bones) and parent_index != i:
                    direction = head - global_positions[parent_index]
                else:
                    direction = Vector((0.0, 1.0, 0.0))

            if direction.length < 1.0e-6:
                direction = Vector((0.0, 1.0, 0.0))
            direction.normalize()

            source_matrix = get_global_matrix(i).to_3x3()
            roll_reference = source_matrix @ Vector((0.0, 0.0, 1.0))
            roll_reference -= direction * roll_reference.dot(direction)

            if roll_reference.length < 1.0e-6:
                roll_reference = source_matrix @ Vector((1.0, 0.0, 0.0))
                roll_reference -= direction * roll_reference.dot(direction)

            if roll_reference.length < 1.0e-6:
                roll_reference = Vector((0.0, 0.0, 1.0))
            roll_reference.normalize()

            if children[i]:
                length = (target - head).length
            elif bone["parent"] >= 0 and bone["parent"] < len(bones):
                length = (head - global_positions[bone["parent"]]).length
            else:
                length = 0.1

            length = max(length, 0.01)
            eb.tail = head + direction * length
            eb.align_roll(roll_reference)
            edit_bones.append(eb)

        for i, bone in enumerate(bones):
            eb = edit_bones[i]
            parent_index = bone["parent"]
            if parent_index >= 0 and parent_index < len(edit_bones) and parent_index != i:
                eb.parent = edit_bones[parent_index]
                eb.use_connect = False

        bpy.ops.object.mode_set(mode="OBJECT")
        arm_data.display_type = 'OCTAHEDRAL'
        arm_obj.show_in_front = True

        for obj in created:
            modifier = obj.modifiers.new("BModel Armature", "ARMATURE")
            modifier.object = arm_obj
            for bone in bones:
                obj.vertex_groups.new(name=bone["name"])
            mesh = obj.data
            for vi in range(len(mesh.vertices)):
                # Attributes are per-point and were imported above.
                for slot in range(4):
                    bone_attr = mesh.attributes.get("BMODEL_BONE%d" % slot)
                    weight_attr = mesh.attributes.get("BMODEL_WEIGHT%d" % slot)
                    if bone_attr and weight_attr:
                        w = weight_attr.data[vi].value
                        bi = bone_attr.data[vi].value
                        if w > 0.0 and bi < len(bones):
                            obj.vertex_groups[bi].add([vi], w, "REPLACE")

    if created:
        bpy.context.view_layer.objects.active = created[0]
        for obj in created:
            obj.select_set(True)

    return created


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def _get_custom_scalar(mesh, name, index, default=0.0):
    attr = mesh.attributes.get(name)
    if attr and attr.domain == "POINT" and index < len(attr.data):
        try:
            return float(attr.data[index].value)
        except Exception:
            pass
    return default


def _get_custom_int(mesh, name, index, default=0):
    attr = mesh.attributes.get(name)
    if attr and attr.domain == "POINT" and index < len(attr.data):
        try:
            return int(attr.data[index].value)
        except Exception:
            pass
    return default


def find_armature(objects):
    armatures = []
    for obj in objects:
        for modifier in obj.modifiers:
            if modifier.type == "ARMATURE" and modifier.object and modifier.object.type == "ARMATURE":
                if modifier.object not in armatures:
                    armatures.append(modifier.object)
        if obj.parent and obj.parent.type == "ARMATURE" and obj.parent not in armatures:
            armatures.append(obj.parent)

    if len(armatures) > 1:
        raise ValueError("Selected meshes reference more than one armature.")
    return armatures[0] if armatures else None


def collect_bones(armature):
    if armature is None:
        return []

    bones = list(armature.data.bones)
    bone_index = {bone.name: i for i, bone in enumerate(bones)}
    result = []

    for bone in bones:
        # BModel bone transforms are stored relative to their PARENT (the same
        # convention BAnim uses for animation frames), not in scene/world space.
        # The engine composes world-space bind matrices itself by walking the
        # parent chain at load time.
        #
        # bone.matrix_local is Blender's cumulative armature-space transform for
        # this bone (i.e. already composed through the parent chain within the
        # armature), so a parent-relative delta is parent.matrix_local^-1 @
        # bone.matrix_local. That delta is invariant under any transform common
        # to both bones, so armature.matrix_world does NOT belong here - it
        # would cancel out for every non-root bone anyway, and applying it to
        # every bone (as before) double-counted it all the way down the chain.
        #
        # The root bone has no parent to cancel armature.matrix_world against,
        # so it's applied once, there, to bring the skeleton into scene space -
        # matching how the mesh vertices are exported (obj.matrix_world).
        if bone.parent:
            local_matrix = bone.parent.matrix_local.inverted() @ bone.matrix_local
        else:
            local_matrix = armature.matrix_world @ bone.matrix_local

        global_matrix = transform_bmodel_matrix(local_matrix)
        position = global_matrix.to_translation()
        orientation = global_matrix.to_quaternion()
        result.append({
            "name": bone.name,
            "parent": bone_index.get(bone.parent.name, -1) if bone.parent else -1,
            "position": (float(position.x), float(position.y), float(position.z)),
            "orientation": (float(orientation.x), float(orientation.y), float(orientation.z), float(orientation.w)),
        })

    return result


def get_vertex_weights(obj, vertex_index, bone_index):
    weights = []
    for group in obj.vertex_groups:
        bi = bone_index.get(group.name)
        if bi is None:
            continue
        try:
            value = group.weight(vertex_index)
        except RuntimeError:
            continue
        if value > 0.0:
            weights.append((float(value), bi))

    weights.sort(reverse=True)
    weights = weights[:4]

    total = sum(w for w, _ in weights)
    if total > 0.0:
        weights = [(w / total, bi) for w, bi in weights]

    bone = [0, 0, 0, 0]
    weight = [0.0, 0.0, 0.0, 0.0]
    for i, (w, bi) in enumerate(weights):
        bone[i] = bi
        weight[i] = w

    return tuple(bone), tuple(weight)


def _get_custom_vector(mesh, name, index):
    attr = mesh.attributes.get(name)
    if attr and attr.domain == "POINT" and index < len(attr.data):
        try:
            v = attr.data[index].vector
            return (float(v.x), float(v.y), float(v.z))
        except Exception:
            pass
    return None


def collect_export_meshes(objects, output_dir, armature):
    """Triangulate objects and globally deduplicate complete vertex tuples."""
    vertex_map = {}
    vertices = []
    meshes = []
    materials = []
    material_map = {}
    bones = collect_bones(armature)
    bone_index = {bone["name"]: i for i, bone in enumerate(bones)}

    def get_material_index(mat):
        if mat is None:
            key = ("__default__",)
            if key not in material_map:
                material_map[key] = len(materials)
                materials.append(material_to_bmodel(None, output_dir))
            return material_map[key]

        key = id(mat)
        if key not in material_map:
            material_map[key] = len(materials)
            materials.append(material_to_bmodel(mat, output_dir))
        return material_map[key]

    depsgraph = bpy.context.evaluated_depsgraph_get()

    for obj in objects:
        if obj.type != "MESH":
            continue

        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh(
            preserve_all_data_layers=True,
            depsgraph=depsgraph,
        )

        try:
            mesh.calc_loop_triangles()

            if len(mesh.vertices) == 0 or len(mesh.loop_triangles) == 0:
                continue

            has_uv = len(mesh.uv_layers) > 0
            uv_layer = mesh.uv_layers.active if has_uv else None

            # BModel has no per-object transform, so vertex positions are
            # stored in Blender scene/world space.  Transform direction vectors
            # with the appropriate normal matrix so meshes retain their scene
            # orientation even when objects are rotated/scaled.
            object_matrix = obj.matrix_world.copy()
            object_linear = object_matrix.to_3x3()
            # Geometry vertices are Blender-local coordinates. Convert the
            # resulting scene/world position into BModel coordinates after
            # applying the object's Blender world transform. Do not conjugate
            # the object matrix here: the input vertex is still in Blender
            # coordinates.
            bmodel_object_matrix = BLENDER_TO_BMODEL @ object_matrix
            try:
                normal_matrix = object_linear.inverted().transposed()
            except Exception:
                normal_matrix = object_linear

            def transform_direction(v, matrix):
                if v is None:
                    return None
                value = matrix @ Vector(v)
                if value.length > 1.0e-12:
                    value.normalize()
                return (float(value.x), float(value.y), float(value.z))

            # BModel can only store one set of attributes per vertex.  The
            # complete tuple is therefore the deduplication key.  This
            # deliberately splits Blender vertices when a seam requires
            # different UV/normal/tangent data, while all triangles that can
            # share a BModel vertex continue to use the same index.
            use_normal = True
            normal_attr = mesh.attributes.get("BMODEL_NORMAL")
            tangent_attr = mesh.attributes.get("BMODEL_TANGENT")
            binormal_attr = mesh.attributes.get("BMODEL_BINORMAL")

            # Calculate Blender tangents when UVs exist and there isn't a
            # preserved BModel tangent/binormal pair.
            if has_uv and (tangent_attr is None or binormal_attr is None):
                try:
                    mesh.calc_tangents(uvmap=uv_layer.name)
                except Exception:
                    pass

            object_indices = []

            for tri in mesh.loop_triangles:
                tri_indices = []

                for loop_index in tri.loops:
                    loop = mesh.loops[loop_index]
                    vi = loop.vertex_index
                    p_vec = bmodel_object_matrix @ mesh.vertices[vi].co
                    p = (float(p_vec.x), float(p_vec.y), float(p_vec.z))

                    if has_uv:
                        uv = uv_layer.data[loop_index].uv
                        # BModel/runtime uses V increasing downward in the
                        # loader's Vulkan upload path.
                        uv_value = (
                            float(uv.x),
                            1.0 - float(uv.y),
                        )
                    else:
                        uv_value = None

                    # Exact imported BModel normal wins if present. Otherwise
                    # use Blender's loop normal.
                    n = _get_custom_vector(mesh, "BMODEL_NORMAL", vi)
                    if n is None:
                        n = tuple(float(x) for x in loop.normal)

                    t = _get_custom_vector(mesh, "BMODEL_TANGENT", vi)
                    b = _get_custom_vector(mesh, "BMODEL_BINORMAL", vi)

                    if t is None and has_uv:
                        try:
                            t = tuple(float(x) for x in loop.tangent)
                        except Exception:
                            t = None

                    if b is None and has_uv:
                        try:
                            b = tuple(float(x) for x in loop.bitangent)
                        except Exception:
                            b = None

                    n = transform_direction(n, normal_matrix)
                    t = transform_direction(t, object_linear)
                    b = transform_direction(b, object_linear)

                    if n is not None:
                        n = transform_bmodel_direction(n)
                    if t is not None:
                        t = transform_bmodel_direction(t)
                    if b is not None:
                        b = transform_bmodel_direction(b)

                    if armature is not None:
                        vertex_bones, vertex_weights = get_vertex_weights(obj, vi, bone_index)
                    else:
                        vertex_bones = (0, 0, 0, 0)
                        vertex_weights = (0.0, 0.0, 0.0, 0.0)

                    # Keep the deduplication key strictly composed of
                    # immutable Python scalar tuples. Blender mathutils
                    # Vectors are mutable/unhashable and must never leak into
                    # this dictionary key.
                    p_key = (float(p[0]), float(p[1]), float(p[2]))
                    uv_key = None if uv_value is None else (
                        float(uv_value[0]), float(uv_value[1])
                    )
                    n_key = None if n is None else (
                        float(n[0]), float(n[1]), float(n[2])
                    )
                    t_key = None if t is None else (
                        float(t[0]), float(t[1]), float(t[2])
                    )
                    b_key = None if b is None else (
                        float(b[0]), float(b[1]), float(b[2])
                    )

                    key = (
                        p_key,
                        uv_key,
                        n_key,
                        t_key,
                        b_key,
                        tuple(int(x) for x in vertex_bones),
                        tuple(float(x) for x in vertex_weights),
                    )

                    index = vertex_map.get(key)
                    if index is None:
                        index = len(vertices)
                        vertex_map[key] = index

                        vertices.append({
                            "position": p,
                            "uv": uv_value,
                            "normal": n,
                            "tangent": t,
                            "binormal": b,
                            "bone": vertex_bones,
                            "weight": vertex_weights,
                        })

                    tri_indices.append(index)

                object_indices.extend(tri_indices)

            # Material is determined per triangle.  BModel has one material
            # name per mesh, so split an object into BModel meshes by material.
            by_material = {}
            for i in range(0, len(object_indices), 3):
                poly = mesh.polygons[tri.material_index] if False else None

            # Rebuild from loop triangles so the polygon material index is
            # preserved.
            by_material = {}
            cursor = 0
            for tri in mesh.loop_triangles:
                mi = tri.material_index
                by_material.setdefault(mi, []).extend(
                    object_indices[cursor:cursor + 3]
                )
                cursor += 3

            for mi, indices in by_material.items():
                mat = mesh.materials[mi] if mi < len(mesh.materials) else None
                mat_index = get_material_index(mat)
                material_name = materials[mat_index]["name"]

                meshes.append({
                    "name": safe_name(
                        obj.name if len(by_material) == 1
                        else "%s_%s" % (
                            obj.name,
                            safe_name(mat.name if mat else "", "DefaultMaterial"),
                        ),
                        "BModelMesh",
                    ),
                    "material_name": material_name,
                    "indices": indices,
                })

        finally:
            eval_obj.to_mesh_clear()

    if not materials:
        materials.append(material_to_bmodel(None, output_dir))

    return vertices, meshes, materials, bones


def write_bmodel(filepath, vertices, meshes, materials, bones):
    # Optional chunks are only emitted if the entire exported model has that
    # attribute.  This matches the BModel representation, where an attribute
    # array is model-wide rather than per-mesh.
    # BModel stores optional attribute arrays model-wide.  If any source
    # mesh supplies an attribute, emit the array for the whole model and use
    # zero/default values for vertices that did not have one.
    has_uv = any(v["uv"] is not None for v in vertices)
    has_normal = any(v["normal"] is not None for v in vertices)
    has_tangent = any(v["tangent"] is not None for v in vertices)
    has_binormal = any(v["binormal"] is not None for v in vertices)

    with open(filepath, "wb") as f:
        write_u32(f, MAGIC_BMDL)

        write_u32(f, len(materials))
        for mat in materials:
            write_u32(f, MAGIC_MATL)
            write_cstring(f, mat["name"])
            write_f32(f, mat["ambient"])
            write_f32(f, mat["diffuse"])
            write_f32(f, mat["specular"])
            write_f32(f, mat["emission"])
            write_f32(f, (mat["shininess"],))
            write_cstring(f, mat["texture"])

        write_u32(f, len(meshes))
        for mesh in meshes:
            write_u32(f, MAGIC_MESH)
            write_cstring(f, mesh["name"])
            write_cstring(f, mesh["material_name"])

            indices = mesh["indices"]
            if len(indices) % 3:
                raise ValueError("Mesh index count is not a multiple of 3.")

            write_u32(f, len(indices) // 3)
            if indices:
                f.write(struct.pack("<" + "I" * len(indices), *indices))

        write_u32(f, len(vertices))

        # Position is mandatory.
        write_u32(f, MAGIC_VERT)
        for v in vertices:
            write_f32(f, v["position"])

        if has_uv:
            write_u32(f, MAGIC_TEXC)
            for v in vertices:
                write_f32(f, v["uv"] if v["uv"] is not None else (0.0, 0.0))

        if has_tangent:
            write_u32(f, MAGIC_TANG)
            for v in vertices:
                write_f32(f, v["tangent"] if v["tangent"] is not None else (0.0, 0.0, 0.0))

        if has_binormal:
            write_u32(f, MAGIC_BNRM)
            for v in vertices:
                write_f32(f, v["binormal"] if v["binormal"] is not None else (0.0, 0.0, 0.0))

        if has_normal:
            write_u32(f, MAGIC_NORM)
            for v in vertices:
                write_f32(f, v["normal"] if v["normal"] is not None else (0.0, 0.0, 1.0))

        if bones:
            write_u32(f, MAGIC_BONE)
            write_u32(f, len(bones))
            for bone in bones:
                write_cstring(f, bone["name"])
                f.write(struct.pack("<i", int(bone["parent"])))
                write_f32(f, bone["position"])
                write_f32(f, bone["orientation"])

            write_u32(f, MAGIC_BWGT)
            for v in vertices:
                f.write(struct.pack("<IIII", *v["bone"]))
                write_f32(f, v["weight"])


# ---------------------------------------------------------------------------
# BAnim animation export
# ---------------------------------------------------------------------------

def find_export_armature(objects):
    armatures = [o for o in objects if o.type == "ARMATURE"]
    mesh_armature = find_armature([o for o in objects if o.type == "MESH"])

    if armatures and mesh_armature and armatures[0] != mesh_armature:
        raise ValueError("Selected meshes and armature reference different armatures.")

    if len(armatures) > 1:
        raise ValueError("More than one armature is selected.")

    return armatures[0] if armatures else mesh_armature


def collect_animation_bones(armature):
    """Return BModel bone order/name mapping used by BAnim export."""
    bones = list(armature.data.bones)
    return bones, {bone.name: i for i, bone in enumerate(bones)}


def pose_bone_local_transform(armature, pose_bone):
    """Get the current local transform, converted from Z-up to Y-up."""
    if pose_bone.parent:
        matrix = pose_bone.parent.matrix.inverted() @ pose_bone.matrix
    else:
        matrix = pose_bone.matrix.copy()

    matrix = transform_bmodel_matrix(matrix)
    position = matrix.to_translation()
    orientation = matrix.to_quaternion()

    return (
        (float(position.x), float(position.y), float(position.z)),
        (float(orientation.x), float(orientation.y),
         float(orientation.z), float(orientation.w)),
    )


def collect_banim_frames(armature, action):
    """Sample an action at every scene frame in its action frame range."""
    scene = bpy.context.scene
    bones, bone_index = collect_animation_bones(armature)

    if not bones:
        raise ValueError("Armature contains no bones.")

    start, end = action.frame_range
    start_frame = int(round(start))
    end_frame = int(round(end))

    if end_frame < start_frame:
        raise ValueError("Animation action has an invalid frame range.")

    frame_count = end_frame - start_frame + 1
    if frame_count > 0xFFFFFFFF:
        raise ValueError("Animation contains too many frames.")

    old_frame = scene.frame_current
    old_subframe = scene.frame_subframe
    old_action = armature.animation_data.action if armature.animation_data else None

    try:
        if armature.animation_data is None:
            armature.animation_data_create()
        armature.animation_data.action = action

        frames = []
        for frame_number in range(start_frame, end_frame + 1):
            scene.frame_set(frame_number)

            pose = [None] * len(bones)
            for pose_bone in armature.pose.bones:
                index = bone_index.get(pose_bone.name)
                if index is None:
                    continue

                position, orientation = pose_bone_local_transform(
                    armature, pose_bone
                )
                pose[index] = {
                    "position": position,
                    "orientation": orientation,
                }

            for index in range(len(pose)):
                if pose[index] is None:
                    pose[index] = {
                        "position": (0.0, 0.0, 0.0),
                        "orientation": (0.0, 0.0, 0.0, 1.0),
                    }

            frames.append(pose)

    finally:
        scene.frame_set(old_frame, subframe=old_subframe)
        if armature.animation_data:
            armature.animation_data.action = old_action

    fps = scene.render.fps / scene.render.fps_base
    if fps <= 0.0:
        fps = 30.0

    return frames, fps


def write_banim(filepath, name, duration, frame_rate, frames):
    """Write the simple frame-major BAnim format."""
    num_frame = len(frames)
    num_bone = len(frames[0]) if frames else 0

    with open(filepath, "wb") as f:
        write_u32(f, struct.unpack("<I", b"BANM")[0])
        write_cstring(f, name)
        write_f32(f, (duration,))
        write_f32(f, (frame_rate,))
        write_u32(f, num_frame)
        write_u32(f, num_bone)

        for frame in frames:
            if len(frame) != num_bone:
                raise ValueError("BAnim frame bone counts do not match.")
            for bone in frame:
                write_f32(f, bone["position"])
                write_f32(f, bone["orientation"])


class EXPORT_OT_banim(bpy.types.Operator):
    bl_idname = "export_scene.banim"
    bl_label = "Export BAnim"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filename_ext = ".banim"
    filter_glob: bpy.props.StringProperty(default="*.banim", options={"HIDDEN"})

    def execute(self, context):
        try:
            objects = list(context.selected_objects)
            armature = find_export_armature(objects)

            if armature is None:
                self.report({"ERROR"}, "Select an armature or a mesh using an armature.")
                return {"CANCELLED"}

            if armature.animation_data is None or armature.animation_data.action is None:
                self.report({"ERROR"}, "Armature has no active animation action.")
                return {"CANCELLED"}

            action = armature.animation_data.action
            frames, frame_rate = collect_banim_frames(armature, action)

            if not frames:
                self.report({"ERROR"}, "Animation contains no frames.")
                return {"CANCELLED"}

            # The sampler treats duration as one frame period per stored frame.
            duration = len(frames) / frame_rate
            animation_name = safe_name(action.name, os.path.splitext(os.path.basename(self.filepath))[0])

            write_banim(
                self.filepath,
                animation_name,
                duration,
                frame_rate,
                frames,
            )

        except Exception as exc:
            self.report({"ERROR"}, "BAnim export failed: %s" % exc)
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            "Exported BAnim '%s': %d frames, %d bones" %
            (animation_name, len(frames), len(frames[0])),
        )
        return {"FINISHED"}

    def invoke(self, context, event):
        armature = find_export_armature(list(context.selected_objects))
        if armature and armature.animation_data and armature.animation_data.action:
            action_name = armature.animation_data.action.name
            if not self.filepath:
                self.filepath = action_name + ".banim"
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


# ---------------------------------------------------------------------------
# Blender operators
# ---------------------------------------------------------------------------

class IMPORT_OT_bmodel(bpy.types.Operator):
    bl_idname = "import_scene.bmodel"
    bl_label = "Import BModel"
    bl_options = {"UNDO"}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filename_ext = ".bmodel"
    filter_glob: bpy.props.StringProperty(default="*.bmodel", options={"HIDDEN"})

    def execute(self, context):
        try:
            import_bmodel(self.filepath)
        except Exception as exc:
            self.report({"ERROR"}, "BModel import failed: %s" % exc)
            return {"CANCELLED"}

        self.report({"INFO"}, "Imported %s" % os.path.basename(self.filepath))
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class EXPORT_OT_bmodel(bpy.types.Operator):
    bl_idname = "export_scene.bmodel"
    bl_label = "Export BModel"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filename_ext = ".bmodel"
    filter_glob: bpy.props.StringProperty(default="*.bmodel", options={"HIDDEN"})

    def execute(self, context):
        try:
            output_dir = os.path.dirname(os.path.abspath(self.filepath))
            objects = [o for o in context.selected_objects if o.type == "MESH"]

            if not objects:
                self.report({"ERROR"}, "No mesh objects selected.")
                return {"CANCELLED"}

            armature = find_armature(objects)
            vertices, meshes, materials, bones = collect_export_meshes(
                objects, output_dir, armature
            )
            if not vertices:
                self.report({"ERROR"}, "Selected meshes contain no triangles.")
                return {"CANCELLED"}

            write_bmodel(self.filepath, vertices, meshes, materials, bones)

        except Exception as exc:
            self.report({"ERROR"}, "BModel export failed: %s" % exc)
            return {"CANCELLED"}

        self.report({
            "INFO"
        }, "Exported %d vertices, %d meshes, %d materials, %d bones" %
           (len(vertices), len(meshes), len(materials), len(bones)))
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


def menu_import(self, context):
    self.layout.operator(
        IMPORT_OT_bmodel.bl_idname,
        text="vkEngine BModel (.bmodel)"
    )


def menu_export(self, context):
    self.layout.operator(
        EXPORT_OT_bmodel.bl_idname,
        text="vkEngine BModel (.bmodel)"
    )
    self.layout.operator(
        EXPORT_OT_banim.bl_idname,
        text="vkEngine BAnim (.banim)"
    )


classes = (
    IMPORT_OT_bmodel,
    EXPORT_OT_bmodel,
    EXPORT_OT_banim,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_export)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_export)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
